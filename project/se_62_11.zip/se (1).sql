-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2020 at 12:49 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE `borrow` (
  `id` int(11) NOT NULL,
  `id_eq` int(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `detail` varchar(50) NOT NULL,
  `num` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `borrow`
--

INSERT INTO `borrow` (`id`, `id_eq`, `type`, `name`, `detail`, `num`) VALUES
(1, 11111, 'อุปกรณ์ IOT', 'xxxxxxxxx', 'xxxxxxxxxxxxxxx', 2);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `id_eq` varchar(50) NOT NULL,
  `detail` varchar(100) NOT NULL,
  `status` int(50) NOT NULL,
  `num` int(50) NOT NULL,
  `file` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`id`, `type`, `name`, `id_eq`, `detail`, `status`, `num`, `file`) VALUES
(1, 'อุปกรณ์ IOT', 'บอร์ด Raspberrypi', '11111111', 'xxxxxxxxxxxxxxxxxxxx', 1, 20, ''),
(2, 'อุปกรณ์ IOT', 'เซ็นเซอร์', '22222222', 'xxxxxxxxxxxxxxxxxxxx', 2, 0, ''),
(3, 'xxxxxxxxx', 'xxxxxxxxx', 'xxxxxxxxxx', 'xxxxxxxxxxxxxxxxxxxxxxxx', 3, 40, ''),
(4, 'xxxxxxxxx', 'xxxxxxxxx', 'xxxxxxxxxxxx', 'xxxxxxxxxxxxxxxx', 1, 30, ''),
(5, 'xxxxxxx', 'xxxxxx', 'xxxxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxxxxxxxxxxxxx', 1, 10, ''),
(6, 'xxxxxxx', 'xxxxxxxxxxx', 'xxxxxxxxxx', 'xxxxxxxxxxxxxxxxxxxx', 3, 25, ''),
(7, 'xxxxxxxxx', 'xxxxxxxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxx', 1, 22, ''),
(8, 'xxxxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxxxxxxx', 'xxxxxxxxxxxxxx', 'xxxxxxxxxxxxxxxxxxx', 4, 1, ''),
(9, 'xxxxxxx', 'xxxxxxxxxxxxxxxxxxxxxxxx', 'xxxxxx', 'xxxxxxxxxxxxxxxxxxx', 2, 5, '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `firstname`, `lastname`, `username`, `password`, `type`) VALUES
(1, 'a', 'a', 'a', 'a', 'Teacher'),
(2, 'b', 'b', 'b', 'b', 'Student'),
(3, 'Admin', 'Admin', 'admin', 'admin', 'Admin'),
(4, 'c', 'c', 'c', 'c', 'Student'),
(5, 'd', 'd', 'd', 'd', 'Student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `borrow`
--
ALTER TABLE `borrow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
