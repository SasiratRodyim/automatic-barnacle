<title>BORROW</title>

<!DOCTYPE html>
    <html>
        <head>
        <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
            <style>
                .borderEquip {
                    display: inline-block;
                    border-style: groove;
                }
                .borderEquipsub {
                    display: inline-block;
                    height:100%;
                }
                .table-wrapper {
                    background: #fff;
                    padding: 20px;
                    margin: 30px 0;
                    box-shadow: 0 1px 1px rgba(0,0,0,.05);
                }
                .table-title {
                    padding-bottom: 10px;
                    margin: 0 0 10px;
                }
                .table-title h2 {
                    margin: 8px 0 0;
                    font-size: 22px;
                }
                .search-box {
                    position: relative;        
                    float: right;
                }
                .search-box input {
                    height: 34px;
                    border-radius: 20px;
                    padding-left: 35px;
                    border-color: #ddd;
                    box-shadow: none;
                }
                .search-box input:focus {
                    border-color: #3FBAE4;
                }
                .search-box i {
                    color: #a0a5b1;
                    position: absolute;
                    font-size: 19px;
                    top: 8px;
                    left: 10px;
                }
                table.table tr th, table.table tr td {
                    border-color: #e9e9e9;
                }
                table.table-striped tbody tr:nth-of-type(odd) {
                    background-color: #fcfcfc;
                }
                table.table-striped.table-hover tbody tr:hover {
                    background: #f5f5f5;
                }
                table.table th i {
                    font-size: 13px;
                    margin: 0 5px;
                    cursor: pointer;
                }
                table.table th {
                    text-align: center;
                }
                table.table td a {
                    color: #a0a5b1;
                    display: inline-block;
                    margin: 0 5px;
                }
                table.table td a.view {
                    color: #03A9F4;
                }
                table.table td a.edit {
                    color: #FFC107;
                }
                table.table td a.delete {
                    color: #E34724;
                }
                table.table td i {
                    font-size: 19px;
                }    
                .pagination {
                    float: right;
                    margin: 0 0 5px;
                }
                .pagination li a {
                    border: none;
                    font-size: 95%;
                    width: 30px;
                    height: 30px;
                    color: #999;
                    margin: 0 2px;
                    line-height: 30px;
                    border-radius: 30px !important;
                    text-align: center;
                    padding: 0;
                }
                .pagination li a:hover {
                    color: #666;
                }	
                .pagination li.active a {
                    background: #03A9F4;
                }
                .pagination li.active a:hover {        
                    background: #0397d6;
                }
                .pagination li.disabled i {
                    color: #ccc;
                }
                .pagination li i {
                    font-size: 16px;
                    padding-top: 6px
                }
                .hint-text {
                    float: left;
                    margin-top: 6px;
                    font-size: 95%;
                }    
                hr {
                    border-top: 5px solid #5E83C0!important;
                }
            </style>
            <script type="text/javascript">
            $(document).ready(function(){
                $('[data-toggle="tooltip"]').tooltip();
            });
            </script>
        </head>
        <body>
            <div class="p-3">
                <div class="">
                    <div class="m-auto"><span><h2>BORROW&RETURN</h2></span></div>
                    <div class="m-auto"><span><h3>ระบบการยืม-คืนอุปกรณ์</h3></span></div>
                    <div class="m-10"><span>สำหรับนิสิต</span></div>
                </div>
                <div style="margin: 30px;">
                    <div class="container">
                            <div class="pb-2"><h2>อุปกรณ์ที่ต้องการยืม</h2></div>
                            <div class="pb-4"><hr class="solid"></div>
                        </div>
                    <div class="container" style="border-style: groove;" style="width:100%;">
                        <div class="table-wrapper">
                            <div class="table-title">
                                <div style="height: 70px;background-color:#5E83C0">
                                    <div class="col-sm-8 p-3 mh-100  text-white" style="width: 100%;">
                                        <h2>รายชื่ออุปกรณ์</h2>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-sm-6">
                                        <div class="hint-text">แสดง <b>2</b> แถว</div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="search-box col-sm-right">
                                            <i class="material-icons">&#xE8B6;</i>
                                            <input type="text" class="form-control" placeholder="Search&hellip;">
                                        </div>
                                    </div>                                
                                </div>
                            </div>
                            <table class="table table-striped table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th width="200px">เลขครุภัณฑ์</th>
                                        <th width="200px">หมวดหมู่อุปกรณ์</th>
                                        <th width="200px">ชื่ออุปกรณ์</th>
                                        <th width="200px">รายละเอียดอุปกรณ์</th>
                                        <th width="80px">จำนวน</th>
                                        <th width="3%"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>xxxxxxxxxx</td>
                                        <td>อุปกรณ์ IOT</td>
                                        <td>เซ็นเซอร์</td></td>
                                        <td>xxxxxxxxxxxxxxxxxxxx</td>
                                        <td>
                                            <input class="form-control" type="number" value="2">
                                        </td>
                                        <td>
                                            <a href="#">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </td>
                                    </tr> 
                                    <tr>
                                        <td>xxxxxxxxxx</td>
                                        <td>อุปกรณ์ IOT</td>
                                        <td>บอร์ด Raspberrypi</td></td>
                                        <td>xxxxxxxxxxxxxxxxxxxx</td>
                                        <td>
                                            <input class="form-control" type="number" value="1">
                                        </td>
                                        <td>
                                            <a href="#">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </td>
                                    </tr>     
                                </tbody>
                            </table>
                            <div class="clearfix">
                                <ul class="pagination">
                                    <li class="page-item disabled"><a href="#"><i class="fa fa-angle-double-left"></i></a></li>
                                    <li class="page-item"><a href="#" class="page-link">1</a></li>
                                    <li class="page-item"><a href="#" class="page-link">2</a></li>
                                    <li class="page-item active"><a href="#" class="page-link">3</a></li>
                                    <li class="page-item"><a href="#" class="page-link">4</a></li>
                                    <li class="page-item"><a href="#" class="page-link">5</a></li>
                                    <li class="page-item"><a href="#" class="page-link"><i class="fa fa-angle-double-right"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>     
                </div>
            </div>
        </body>
    </html>

    <style type="text/css">
 body { background: url(https://m0.her.ie/wp-content/uploads/2017/07/12173030/iStock-510482146.jpg) 
 no-repeat center center fixed; filter:-webkit-background-size: cover; -moz-background-size: cover;
 -o-background-size: cover; background-size: cover;} </style>
