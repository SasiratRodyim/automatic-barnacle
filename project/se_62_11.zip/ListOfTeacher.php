<title>Teacher</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
   

    <link rel="canonical" href="https://getbootstrap.com/docs/4.4/examples/product/">

    <!-- Bootstrap core CSS -->
<link href="/docs/4.4/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/4.4/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/4.4/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/4.4/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/4.4/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/4.4/assets/img/favicons/safari-pinned-tab.svg" color="#563d7c">
<link rel="icon" href="/docs/4.4/assets/img/favicons/favicon.ico">
<meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
<meta name="theme-color" content="#563d7c">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="product.css" rel="stylesheet">
  </head>
  <body>
    
  <div class="container d-flex flex-column flex-md-row justify-content-between">
    <a class="py-2" href="#" aria-label="home">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="d-block mx-auto" role="img" viewBox="0 0 24 24" focusable="false"><title></title></svg>
    </a>
    <a class="d-none d-md-inline-block" href="login.php"><button type="submit" class="btn btn-info" id="btn" name="btnSubmit">
            <span class="glyphicon glyphicon-log-in"stroke="#000" stroke-width="1" font-size="40" font-family="LeelawadeeUI, Leelawadee UI" ></span>
             ระบบยืมคืนอุปกรณ์ </button> </a>
    <a class="py-2 d-none d-md-inline-block"fill="#f9f9f9" stroke="#000" stroke-width="3" font-size="26" font-family="SegoeUI, Segoe UI"  href="ListOfTeacher.php">TEACHER</a>
    <a class="py-2 d-none d-md-inline-block"fill="#f9f9f9" stroke="#000" stroke-width="3" font-size="26" font-family="SegoeUI, Segoe UI"  href="equipments1.php">EQUPMENT</a>
    <a class="py-2 d-none d-md-inline-block"fill="#f9f9f9" stroke="#000" stroke-width="3" font-size="26" font-family="SegoeUI, Segoe UI"  href="borrow.php">BOWROW&RETURN</a>
    <a class="py-2 d-none d-md-inline-block"fill="#f9f9f9" stroke="#000" stroke-width="3" font-size="26" font-family="SegoeUI, Segoe UI"  href="contact.php">CONTACT</a>
    <a class="py-2 d-none d-md-inline-block"fill="#f9f9f9" stroke="#000" stroke-width="3" font-size="26" font-family="SegoeUI, Segoe UI" href="history-se.php">HISTORY</a>
    
  </div>
  </div>



<div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center">
    <h1 class="display-4 font-weight-normal">WELCOME TO BORROW&RETURN</h1>
    <p class="lead font-weight-normal">ระบบยืม-คืนอุปกรณ์คอมพิวเตอร์ของคณะวิศวกรรมศาสตร์ สาขาคอมพิวเตอร์และอิเล็กทรอนิกส์
    <p class="lead font-weight-normal">มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน</p></p>
    

    <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #000000;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}



.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>
        <body>
        <center>
        <div class="border border-dark bg-white mr-md-3 pt-3 px-3 pt-md-5 px-md-5 text-left text-black overflow-hidden">
            <div class="container">
                <div class="col-12 p-5" style="text-align:center;">
                    <h2>List of Teachers</h2>
                    
                </div>
                <div class="row">
                    <div class="col-4" style="text-align:center;"><img src="seksan.jpg"  style="margin-top:18px"/></div>
                    <div class="col-4" style="text-align:center;"><img src="amornrit.jpg"  style="margin-top:18px"/></div>
                    <div class="col-4" style="text-align:center;"><img src="thitipong.jpg"  style="margin-top:18px"/></div>
                </div>
                <div class="row">
                    <div class="col-4" style="text-align:center;"><span><h5>อ.ดร.เสกสรรค์ มธุลาภรังสรรค์<br>Seksan Mathulaprangsan, Ph.D.<br>fengssmt@ku.ac.th  |  7523</h5></span></div>
                    <div class="col-4" style="text-align:center;"><span><h5>ผศ.ดร.อมรฤทธิ์   พุทธิพิพัฒน์ขจร<br>Asst. Prof. Amornrit Puttipipatkajorn, Ph.D.<br> fengarp@ku.ac.th  |  7525</h5></span></div>
                    <div class="col-4" style="text-align:center;"><span><h5>ผศ.ดร.ฐิติพงษ์   สถิรเมธีกุล<br>Asst. Prof. Thitipong Satiramatekul, Ph.D. <br>fengtps@ku.ac.th  |  7529</h5></span></div>
                </div>
                <div class="row">
                    <div class="col-4" style="text-align:center;"><img src="chakkrit.jpg"  style="margin-top:18px"/></div>
                    <div class="col-4" style="text-align:center;"><img src="nutchanat.jpg"  style="margin-top:18px"/></div>
                    <div class="col-4" style="text-align:center;"><img src="siwadol.jpg"  style="margin-top:18px"/></div>
                </div>
                <div class="row">
                    <div class="col-4" style="text-align:center;"><span><h5>ผศ.ดร.จักกริช พฤษการ <br>Asst.Prof.Chakkrit Preuksakarn, Ph.D. <br>chakkrit.p@ku.ac.th  |<br>
7522, 7526, 7528 ต่อ 12</h5></span></div>
                    <div class="col-4" style="text-align:center;"><span><h5>ผศ.นุชนาฎ   สัตยากวี<br>Asst. Prof. Nutchanat Sattayakawee<br>fengncn@ku.ac.th  |  7524</h5></span></div>
                    <div class="col-4" style="text-align:center;"><span><h5>อ.ดร.ศิวดล เสถียรพัฒนากูล<br>Siwad<br>ol Sateanpattanakul, Ph.D.<br>fengsds@ku.ac.th  |<br>7522, 7526, 7528 ต่อ 14</h5></span></div>
                </div>
                <div class="row">
                    <div class="col-4" style="text-align:center;"><img src="anumat.jpg" style="margin-top:18px"/></div>
                    <div class="col-4" style="text-align:center;"><img src="varunya.jpg" style="margin-top:18px"/></div>
                    <div class="col-4" style="text-align:center;"><img src="boonyarat.jpg"  style="margin-top:18px"/></div>
                </div>
                <div class="row">
                    <div class="col-4" style="text-align:center;"><span><h5>อ.ร้อยโทอนุมัติ อิงคนินันท์<br>Mr.Anumat Engkaninan<br>fengame@ku.ac.th  |  7523	</h5></span></div>
                    <div class="col-4" style="text-align:center;"><span><h5>อ.ดร.วรัญญา  อรรถเสนา<br>Varunya Attasena, Ph.D.<br>fengvry@ku.ac.th  |  7528</h5></span></div>
                    <div class="col-4" style="text-align:center;"><span><h5>อ.ดร.บุญรัตน์  เผดิมรอด<br>Boonyarat Phadermrod, Ph.D.<br>fengbyr@ku.ac.th  |<br>7522, 7526, 7528 ต่อ 16</h5></span></div>
                </div>
                <div class="row">
                    <div class="col-4" style="text-align:center;"><img src="Pichet.jpg" style="margin-top:18px"/></div>
                    <div class="col-4" style="text-align:center;"><img src="kairat.jpg" style="margin-top:18px"/></div>
                    <div class="col-4" style="text-align:center;"><img src="duangpen.jpg" style="margin-top:18px"/></div>
                </div>
                <div class="row">
                    <div class="col-4" style="text-align:center;"><span><h5>อ.ดร.พิเชษฐ์  สืบสายพรหม <br> Pichet Suebsaiprom, Ph.D.<br> fengpcsu@ku.ac.th  |  </h5></span></div>
                    <div class="col-4" style="text-align:center;"><span><h5>อ.ดร.กายรัฐ  เจริญราษฎร์<br>Kairat Jeroenrat, Ph.D.<br>fengkrj@ku.ac.th  |<br>7522, 7526, 7528 ต่อ 11	
</h5></span></div>
                    <div class="col-4" style="text-align:center;"><span><h5>ผศ.ดร.ดวงเพ็ญ  เจตน์พิพัฒนพงษ์ <br>	Asst.Prof.Duangpen Jetpipattanapong, Ph.D.<br>fengdpj@ku.ac.th  |<br>7522, 7526, 7528 ต่อ 15</h5></span></div>
                </div><br>
                <h1 class="display-5 font-weight-normal">___________________________________________________________________________________________________________________</h1>
                <br><div class="row">
                    <div class="col-4" style="text-align:center;"><img src="jutatip.jpg"  style="margin-top:18px"/></div>
                    <div class="col-4" style="text-align:center;"><img src="sasitorn.jpg"  style="margin-top:18px"/></div>
                    <div class="col-4" style="text-align:center;"><img src="monthicha.jpg"  style="margin-top:18px"/></div>
                </div>
                <div class="row">
                    <div class="col-4" style="text-align:center;"><span><h5>น.ส.จุฑาทิพย์  ทรัพย์ฤทธา<br>Miss Jutatip Subrittra<br>fengjts@ku.ac.th  |  7523</h5></span></div>
                    <div class="col-4" style="text-align:center;"><span><h5>น.ส.ศศิธร   ชลรัตน์อมฤต<br>Miss Sasitorn Chonratammarit<br>fengsstc@ku.ac.th   |  7527</h5></span></div>
                    <div class="col-4" style="text-align:center;"><span><h5>น.ส.มณฑิชา กิจสมสาตร์<br>Miss Monticha Kidsomsad<br>fengmcn@ku.ac.th  |  7523</h5></span></div>
                </div>
                <div class="row">
                    <div class="col-4" style="text-align:center;"><img src="aekkalak.jpg" style="margin-top:18px"/></div>
                    <div class="col-4" style="text-align:center;"><img src="sorapong.jpg" style="margin-top:18px"/></div>
                </div>
                <div class="row">
                    <div class="col-4" style="text-align:center;"><span><h5>นายเอกลักษณ์ เรืองศรี<br>Mr.Aekkalux Reungsri<br>fengalr@ku.ac.th  |  7527</h5></span></div>
                    <div class="col-4" style="text-align:center;"><span><h5>นายวรธนัท เกตุศิริ<br>Mr.Worathanat Ketsiri<br>fengsok@ku.ac.th  |  7527</h5></span></div>
                </div>
                
            </div></div></div>
        </body>
    </html>

     <style type="text/css">
 body { background: url(https://m0.her.ie/wp-content/uploads/2017/07/12173030/iStock-510482146.jpg) 
 no-repeat center center fixed; filter:-webkit-background-size: cover; -moz-background-size: cover;
 -o-background-size: cover; background-size: cover;} </style>
