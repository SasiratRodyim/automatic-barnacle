<?php
    session_start();

    if (isset($_POST['username'])) {

      include('connection_connect.php');

      $username = $_POST['username'];
      $password = $_POST['password'];
      

      $query = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";

      $result = mysqli_query($conn, $query);

      if (mysqli_num_rows($result) == 1){

        $row = mysqli_fetch_array($result);

        $_SESSION['username'] = $username;
        
        $_SESSION['userid'] = $row['id'];
        $_SESSION['user'] = $row['firstname'] . " " . $row['lastname'];
        $_SESSION['type'] = $row['type'];

      if ($_SESSION['type'] == 'Teacher') {
        header("Location: home2.php");
      }
      if ($_SESSION['type'] == 'Student') {
        header("Location: home1.php");
      }
      if ($_SESSION['type'] == 'Admin') {
        header("Location: home3.php");
      }
      }
      else {
        echo "<script>alert('Username หรือ Password ไม่ถูกต้อง');</script>";
      }
    }
?>
<title>BORROW&&RETURN</title>


<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>BORROW&&RETURN</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.4/examples/product/">

    <!-- Bootstrap core CSS -->
<link href="/docs/4.4/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/4.4/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/4.4/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/4.4/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/4.4/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/4.4/assets/img/favicons/safari-pinned-tab.svg" color="#563d7c">
<link rel="icon" href="/docs/4.4/assets/img/favicons/favicon.ico">
<meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
<meta name="theme-color" content="#563d7c">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="product.css" rel="stylesheet">
  </head>
  <body>
    
  <div class="container d-flex flex-column flex-md-row justify-content-between">
    <a class="py-2" href="#" aria-label="home">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="d-block mx-auto" role="img" viewBox="0 0 24 24" focusable="false"><title></title></svg>
    </a>
    <a class="d-none d-md-inline-block" href="login.php"><button type="submit" class="btn btn-info" id="btn" name="btnSubmit">
            <span class="glyphicon glyphicon-log-in"> </span>
             ระบบยืมคืนอุปกรณ์ </button> </a>
    <a class="py-2 d-none d-md-inline-block" href="login.php">HOME</a>
    <a class="py-2 d-none d-md-inline-block" href="ListofTeacher.php">TEACHER</a>
    <a class="py-2 d-none d-md-inline-block" href="equipments1.php">EQUPMENT</a>
    <a class="py-2 d-none d-md-inline-block" href="borrow.php">BOWROW&RETURN</a>
    <a class="py-2 d-none d-md-inline-block" href="contact.php">CONTACT</a>
    <a class="py-2 d-none d-md-inline-block" href="history-se.php">HISTORY</a>
    
  </div>
  </div>



<div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center">
    <br><br><h1 class="display-4 font-weight-normal">WELCOME TO BORROW&RETURN</h1>
    <p class="lead font-weight-normal">ระบบยืม-คืนอุปกรณ์คอมพิวเตอร์ของคณะวิศวกรรมศาสตร์ สาขาคอมพิวเตอร์และอิเล็กทรอนิกส์
    <p class="lead font-weight-normal">มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน</p></p>
    
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #000000;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #000000;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}



.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>


<button class="btn btn-outline-secondary" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">เข้าสู่ระบบ</button>

<div id="id01" class="modal">
  
  <form class="modal-content animate" action="login.php" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      
    </div>

    <div class="container">
      <b>Username</b>
      <input type="text"  name="username" class="form-control" required placeholder="Username" />

      <b>Password</b></label>
      <input type="password" name="password" class="form-control" required placeholder="Password" />
          
      <button type="submit" class="btn btn-info" id="btn" name="btnSubmit"><span class="glyphicon glyphicon-log-in"> </span>
             Login </button><br><br>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button><br>
      <span class="psw">Forgot <a href="#">password?</a></span>
    </div>
  </form>
</div></div>
<br><br><br><br><br><br><br><br><br>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</body>
</html>



  </div>
  <div class="product-device shadow-sm d-none d-md-block"></div>
  <div class="product-device product-device-2 shadow-sm d-none d-md-block"></div>
</div>





  



<style type="text/css">
 body { background: url(https://m0.her.ie/wp-content/uploads/2017/07/12173030/iStock-510482146.jpg) 
 no-repeat center center fixed; filter:-webkit-background-size: cover; -moz-background-size: cover;
 -o-background-size: cover; background-size: cover;} </style>
<div id="footer"><nav class="site-header sticky-top py-1 bg-white ">
<footer class="container py-5 ">
<div class="d-md-flex flex-md-equal w-100 my-md-3 pl-md-3 ">
  
    <div class="my-3 py-3 ">
      <h2 class="display-5 font-weight-normal">About US</h2>
      <IMG SRC = cpe.jpg width=300 height=300>
    </div>
    <div class=" mx-auto" style="width: 80%; height: 300px; border-radius: 21px 21px 0 0;">
    <ul class="list-unstyled text-small text-center ">
    <small><font color="black"><p class="lead">ให้การศึกษาเพื่อผลิตบัณฑิตในสาขาวิศวกรรมคอมพิวเตอร์ โดยมุ่งเน้นด้านเทคโนโลยีคอมพิวเตอร์อย่างลึกซึ้ง ทั้งด้านฮาร์ดแวร์และซอฟท์แวร์ เช่น สถาปัตยกรรมคอมพิวเตอร์ การสื่อสารข้อมูลและเครือข่ายคอมพิวเตอร์ อัลกอริทึมและปัญหาเชิงคำนวณ การประยุกต์ใช้งานไมโครโปรเซสเซอร์ การโปรแกรมระบบ ปัญญาประดิษฐ์ วิศวกรรมซอฟต์แวร์ การพัฒนาระบบงานคอมพิวเตอร์ ระบบการจัดการฐานข้อมูล และเทคโนโลยีสารสนเทศเพื่อการจัดการ ฯลฯ บัณฑิตที่สำเร็จการศึกษาสามารถประกอบอาชีพเป็นนักวิเคราะห์ และพัฒนาระบบงานวิศวกรคอมพิวเตอร์ วิศวกรระบบ และผู้บริหารระบบงานสารสนเทศในหน่วยงานของรัฐและเอกชนได้</p>
    </div></font></small></div>

  <div class="row">
    <div class="col-12 col-md">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="d-block mb-2" role="img" viewBox="0 0 24 24" focusable="false"></svg>
      <small class="d-block mb-3 text-muted text-center">Copyright © 2020</small>
    <div class="col-6 col-md text-center">
      <h5>BORROW&RETURN</h5>
      <ul class="list-unstyled text-small text-center ">
        <li><a class="text-muted"> Engineering KPS. All Rights Reserved. คณะวิศวกรรมศาสตร์ กำแพงแสน มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน อ.กำแพงแสน จ.นครปฐม 73140 ติดต่อคณะฯ โทร. 0-3428-1074 , 0-3435-1897</a></li>
      </ul>
    </div>
    </div>
  </div>
</footer>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
      <script>window.jQuery || document.write('<script src="/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')</script><script src="/docs/4.4/dist/js/bootstrap.bundle.min.js" integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>

    
</body></html></div>