<title>HOME</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
   

    <link rel="canonical" href="https://getbootstrap.com/docs/4.4/examples/product/">

    <!-- Bootstrap core CSS -->
<link href="/docs/4.4/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!-- Favicons -->
<link rel="apple-touch-icon" href="/docs/4.4/assets/img/favicons/apple-touch-icon.png" sizes="180x180">
<link rel="icon" href="/docs/4.4/assets/img/favicons/favicon-32x32.png" sizes="32x32" type="image/png">
<link rel="icon" href="/docs/4.4/assets/img/favicons/favicon-16x16.png" sizes="16x16" type="image/png">
<link rel="manifest" href="/docs/4.4/assets/img/favicons/manifest.json">
<link rel="mask-icon" href="/docs/4.4/assets/img/favicons/safari-pinned-tab.svg" color="#563d7c">
<link rel="icon" href="/docs/4.4/assets/img/favicons/favicon.ico">
<meta name="msapplication-config" content="/docs/4.4/assets/img/favicons/browserconfig.xml">
<meta name="theme-color" content="#563d7c">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <!-- Custom styles for this template -->
    <link href="product.css" rel="stylesheet">
  </head>
  <body>
    
  <div class="container d-flex flex-column flex-md-row justify-content-between">
    <a class="py-2" href="#" aria-label="home">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="d-block mx-auto" role="img" viewBox="0 0 24 24" focusable="false"><title></title></svg>
    </a>
    <a class="d-none d-md-inline-block" href=""><button type="submit" class="btn btn-info" id="btn" name="btnSubmit">
            <span class="glyphicon glyphicon-log-in"stroke="#000" stroke-width="1" font-size="40" font-family="LeelawadeeUI, Leelawadee UI" ></span>
             ระบบยืมคืนอุปกรณ์ </button> </a>
    <a class="py-2 d-none d-md-inline-block"fill="#f9f9f9" stroke="#000" stroke-width="3" font-size="26" font-family="SegoeUI, Segoe UI"  href="login.php">HOME</a>
    <a class="py-2 d-none d-md-inline-block"fill="#f9f9f9" stroke="#000" stroke-width="3" font-size="26" font-family="SegoeUI, Segoe UI"  href="ListOfTeacher.php">TEACHER</a>
    <a class="py-2 d-none d-md-inline-block"fill="#f9f9f9" stroke="#000" stroke-width="3" font-size="26" font-family="SegoeUI, Segoe UI"  href="equipments1.php">EQUPMENT</a>
    <a class="py-2 d-none d-md-inline-block"fill="#f9f9f9" stroke="#000" stroke-width="3" font-size="26" font-family="SegoeUI, Segoe UI"  href="borrow.php">BOWROW&RETURN</a>
    <a class="py-2 d-none d-md-inline-block"fill="#f9f9f9" stroke="#000" stroke-width="3" font-size="26" font-family="SegoeUI, Segoe UI"  href="contact.php">CONTACT</a>
    <a class="py-2 d-none d-md-inline-block"fill="#f9f9f9" stroke="#000" stroke-width="3" font-size="26" font-family="SegoeUI, Segoe UI" href="history-se.php">HISTORY</a>
    <a class="d-none d-md-inline-block" href="login.php"><button type="submit" class="btn btn-info" id="btn" name="btnSubmit">
            <span class="glyphicon glyphicon-log-in"stroke="#000" stroke-width="1" font-size="40" font-family="LeelawadeeUI, Leelawadee UI" ></span>
             ออกจากระบบ </button> </a>
  </div>
  </div>



<div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center">
<font color="black"><h1 class="display-4 font-weight-normal ">WELCOME TO BORROW&RETURN</h1>
    <p class="lead font-weight-normal">ระบบยืม-คืนอุปกรณ์คอมพิวเตอร์ของคณะวิศวกรรมศาสตร์ สาขาคอมพิวเตอร์และอิเล็กทรอนิกส์
    <p class="lead font-weight-normal">มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน</p></p></font>
    

    <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #000000;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}



.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 60px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>

<style type="text/css"> /* code by https://codesoichat.online/background/ */ body { background: url(https://m0.her.ie/wp-content/uploads/2017/07/12173030/iStock-510482146.jpg) no-repeat center center fixed; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover; } </style>

<center><div class="d-md-flex flex-md-equal w-100 my-md-3 pl-md-3 " style=" height: 200px;"></center>
<div class="border border-dark bg-white mr-md-3 pt-3 px-3 pt-md-5 px-md-5 text-left text-black overflow-hidden">
<div style="margin: 30px;">
                <div class="container" style="border-style: groove;" style="width:100%;">
                    <div class="table-wrapper">
                        <div class="table-title">
                            <div style="height: 70px;background-color:#5E83C0">
                                <div class="col-sm-8 p-3 mh-100  text-white" style="width: 100%;">
                                    <h2>รายชื่ออุปกรณ์ทั้งหมด</h2>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-sm-6">
                                </div>
                                <div class="col-sm-6">
                                    <div class="search-box col-sm-right">
                                        <i class="material-icons">&#xE8B6;</i>
                                        <input type="text" class="form-control" placeholder="Search&hellip;">
                                    </div>
                                </div>                                
                            </div>
                        </div>
                        <table class="table table-striped table-hover table-bordered">
                            <thead>
                                <tr>
                                <th width="100px">ลำดับ</th>
                                    <th width="100px">เลขครุภัณฑ์</th>
                                    <th width="100px">หมวดหมู่อุปกรณ์</th>
                                    <th width="100px">ชื่ออุปกรณ์</th>
                                    <th width="100px">รายละเอียดอุปกรณ์</th>
                                    <th width="100px">จำนวน</th>
                                    <th width="100px">สถานะอุปกรณ์</th>
                                    <th width="3%"></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
			$sql = "Select * from equipment";
                        require('connection_connect.php');
                        $result = $conn -> query($sql);
                        $i = 1;
                        while($row = mysqli_fetch_assoc($result)){
                            
                    ?>
                            <tbody>
                            <tr>
                    <td><?php echo $i;?></td>
                    <td><?php echo $row['id_eq'];?></td>
                    <td><?php echo $row['type'];?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['detail'];?></td>
                    <td><?php echo $row['num'];?></td>
                    <td><?php 
                    if($row['status'] == 1)
                    echo"ว่าง";
                elseif($row['status'] == 2){
                    echo "ไม่ว่าง";
                }
                elseif($row['status'] == 3){
                    echo "ชำรุด";
                }
                elseif($row['status'] == 4){
                    echo "ใช้ภายในคณะ";
                }?>
                </td>
                <td><?php echo $row['file'];?></td>
                </tr>
		            <?php 
                        $i = $i+1;
                    }
                    ?>        
                            </tbody>
                        </table>
                    </div>
                </div>     
            </div>
        </body>

    <footer class="container py-5 bg-light shadow-sm ">
  <div class="row">
    <div class="col-12 col-md ">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="20" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="d-block mb-2" role="img" viewBox="0 0 24 24" focusable="false"></svg>
      <small class="d-block mb-3 text-muted text-center">Copyright © 2020</small>
    <div class="col-6 col-md text-center">
      <h5>BORROW&RETURN SYSTEM</h5>
      <ul class="list-unstyled text-small text-center ">
        <li><a class="text-muted"> Engineering KPS. All Rights Reserved. คณะวิศวกรรมศาสตร์ กำแพงแสน มหาวิทยาลัยเกษตรศาสตร์ วิทยาเขตกำแพงแสน อ.กำแพงแสน จ.นครปฐม 73140 ติดต่อคณะฯ โทร. 0-3428-1074 , 0-3435-1897</a></li>
      </ul>
    </div>
    </div>
  </div>
</footer>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
      <script>window.jQuery || document.write('<script src="/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')</script><script src="/docs/4.4/dist/js/bootstrap.bundle.min.js" integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>

  </div>
</div>




